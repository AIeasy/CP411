#include "House.hpp"

House::House()
{
	// set set cordinate values for all vertices
    // other faces
	GLfloat v[8][3] = { { -1., -1., -1.},
			{ -1, 1.,-1.},
			{ 1., 1., -1},
			{ 1., -1, -1},
			{ -1, -1, 1.},
			{ -1, 1., 1.},
			{ 1., 1., 1.},
			{ 1., -1, 1.} };
	for (int i=0;i<8;i++){
		for(int j=0;j<4;j++){
			vertex[i][j]=v[i][j];
		}
	}
	GLint facel[6][4] = { { 0, 1, 2, 3 }, // face[0]
	{ 7, 6, 5, 4 }, // face[1]
	{ 0, 4, 5, 1 }, // face[2]
	{ 2, 1, 5, 6 }, // face[3]
	{ 3, 2, 6, 7 }, // face[4]
	{ 0, 3, 7, 4 } // face[5]
	};
	for (int x=0;x<6;x++){
		for (int y=0;y<4;y++){
			face[x][y]=facel[x][y];
		}
	}






	GLfloat pv[5][3] = { { -1, -1, 1},
			{ -1, 1,1},//X Y Z
			{ 1, -1, 1},//x y z
			{ 1, 1, 1},
			{ 0, 0, 2},//x y z
			};
		for (int i=0;i<5;i++){
			for(int j=0;j<3;j++){
				pvertex[i][j]=pv[i][j];
			}
		}

		GLint side[4][3] = { { 0, 1, 4 }, // face[0]
		{ 2, 3, 4}, // face[1]
		{ 0, 2, 4 }, // face[2]
		{ 1, 4,3}, // face[3]
		//{ 3, 2, 6, 7 }, // face[4]
		//{ 0, 3, 7, 4 } // face[5]
		};
		GLint bott[1][4]={{0,1,2,3}
		};
		for (int i =0;i<1;i++){
			for (int j =0;j<4;j++){
				bot[i][j]=bott[i][j];
			}
		}
		for (int x=0;x<4;x++){
			for (int y=0;y<3;y++){
				pface[x][y]=side[x][y];
			}
		}
    r = 0.0;
    g = 0.0;
    b = 1.0;
}

void House::drawFace(int i)
{
// draw face i
    glBegin(GL_LINE_LOOP);
    glVertex3fv(vertex[face[i][0]]);
    glVertex3fv(vertex[face[i][1]]);
    glVertex3fv(vertex[face[i][2]]);
    glVertex3fv(vertex[face[i][3]]);
    glEnd();

}
void House::drawPFace(int i)
{
// draw face i
    glBegin(GL_LINE_LOOP);
    glVertex3fv(pvertex[pface[i][0]]);
    glVertex3fv(pvertex[pface[i][1]]);
    glVertex3fv(pvertex[pface[i][2]]);

    glEnd();

}
void House::drawBot()
{
// draw face i
    glBegin(GL_LINE_LOOP);

    glVertex3fv(pvertex[1]);

    glVertex3fv(pvertex[0]);

    glVertex3fv(pvertex[2]);

    glVertex3fv(pvertex[3]);
    //glVertex3fv(vertex[face[i][3]]);
    glEnd();

}


void House::draw()
{
    glPushMatrix();
    this->ctmMultiply();
 // set color
    glColor3f(r,g,b);
 // draw all faces
    for(int i=0;i<6;i++){
    	drawFace(i);
    }
    glColor3f(1,0,0);
    glScalef(s,s,s);
    for(int i=0;i<3;i++){
        drawPFace(i);
    }

    drawBot();
    glPopMatrix();
}

