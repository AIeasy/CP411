#include "Cube.hpp"

Cube::Cube()
{
	// set set cordinate values for all vertices
    // other faces
	GLfloat v[8][3] = { { -1., -1., -1.},
	{ -1, 1.,-1.},
	{ 1., 1., -1},
	{ 1., -1, -1},
	{ -1, -1, 1.},
	{ -1, 1., 1.},
	{ 1., 1., 1.},
	{ 1., -1, 1.} };
	for (int i=0;i<8;i++){
		for(int j=0;j<4;j++){
			vertex[i][j]=v[i][j];
		}
	}
	GLint facel[6][4] = { { 0, 1, 2, 3 }, // face[0]
	{ 7, 6, 5, 4 }, // face[1]
	{ 0, 4, 5, 1 }, // face[2]
	{ 2, 1, 5, 6 }, // face[3]
	{ 3, 2, 6, 7 }, // face[4]
	{ 0, 3, 7, 4 } // face[5]
	};
	for (int x=0;x<6;x++){
		for (int y=0;y<4;y++){
			face[x][y]=facel[x][y];
		}
	}
    r = 1.0;
    g = 0.0;
    b = 0.0;
}

void Cube::drawFace(int i)
{
// draw face i
    glBegin(GL_LINE_LOOP);
    glVertex3fv(vertex[face[i][0]]);
    glVertex3fv(vertex[face[i][1]]);
    glVertex3fv(vertex[face[i][2]]);
    glVertex3fv(vertex[face[i][3]]);
    glEnd();

}

void Cube::draw()
{
    glPushMatrix();
    this->ctmMultiply();
 // set color
    glColor3f(r,g,b);
    glScalef(s,s,s);
 // draw all faces
    for(int i=0;i<6;i++){
    	drawFace(i);
    }
    glPopMatrix();
}

