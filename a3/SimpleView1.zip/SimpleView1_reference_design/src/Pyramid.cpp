#include "Pyramid.hpp"


Pyramid::Pyramid()
{
	// set set cordinate values for all vertices
    // other faces
	GLfloat v[5][3] = { { -1, -1, -1},
	{ -1, 1,-1},//X Y Z
	{ 1, -1, -1},//x y z
	{ 1, 1, -1},
	{ 0, 0, 1},//x y z
	};
	for (int i=0;i<5;i++){
		for(int j=0;j<3;j++){
			vertex[i][j]=v[i][j];
		}
	}

	GLint side[4][3] = { { 0, 4, 1 }, // face[0]
	{ 2, 3, 4}, // face[1]
	{ 0, 2, 4 }, // face[2]
	{ 1, 4,3}, // face[3]
	//{ 3, 2, 6, 7 }, // face[4]
	//{ 0, 3, 7, 4 } // face[5]
	};
	GLint bott[1][4]={{0,1,2,3}
	};
	for (int i =0;i<1;i++){
		for (int j =0;j<4;j++){
			bot[i][j]=bott[i][j];
		}
	}
	for (int x=0;x<4;x++){
		for (int y=0;y<3;y++){
			face[x][y]=side[x][y];
		}
	}
    r = 1.0;
    g = 1.0;
    b = 0.0;
}

void Pyramid::drawFace(int i)
{
// draw face i
    glBegin(GL_LINE_LOOP);
    glVertex3fv(vertex[face[i][0]]);
    glVertex3fv(vertex[face[i][1]]);
    glVertex3fv(vertex[face[i][2]]);
    //glVertex3fv(vertex[face[i][3]]);
    glEnd();

}
void Pyramid::drawBot()
{
// draw face i
    glBegin(GL_LINE_LOOP);

    glVertex3fv(vertex[1]);

    glVertex3fv(vertex[0]);

    glVertex3fv(vertex[2]);

    glVertex3fv(vertex[3]);
    //glVertex3fv(vertex[face[i][3]]);
    glEnd();

}

void Pyramid::draw()
{
    glPushMatrix();
    this->ctmMultiply();
 // set color
    glColor3f(r,g,b);
    glScalef(s,s,s);
 // draw all faces
    for(int i=0;i<3;i++){
    	//drawFace(0);
    	//drawFace(1);
    	//drawFace(2);
    	drawFace(i);
    }

    drawBot();
    glPopMatrix();
}

