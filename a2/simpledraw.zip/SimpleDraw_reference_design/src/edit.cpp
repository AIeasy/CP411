/*
 * Description: implementation of edit.hpp
 * Author: HBF
 * Version: 2021-08-24
 */

#include <stdio.h>
#include <GL/glut.h>
#include <math.h>
#include "object.hpp"

extern LIST objlist;

GLint min(GLint x, GLint y) {
	return x < y ? x : y;
}

GLint max(GLint x, GLint y) {
	if (x < y)
		return y;
	else
		return x;
}

NODE *select(GLint x, GLint y) {
	int left = 0;
	int right = 0;
	int top = 0;
	int bot = 0;
	// your implementation
    // search the object that cover the clicking point staring
	if (objlist.start != NULL){
		NODE *p =objlist.start;
		while(p!= NULL){
			if (p->object->type == RECTANGLE){
				if (p->object->x1 > p->object->x2){
					left = p->object->x2;
					right = p->object->x1;
				}else{
					left = p->object->x1;
					right = p->object->x2;
				}
				if (p->object->y1 > p->object->y2){
					top = p->object->y1;
					bot = p->object->y2;
				}else{
					top = p->object->y2;
					bot = p->object->y1;
				}
				if (x>=left && x<=right && y>=bot && y<=top){
					return p;
				}

			}else{//circle
				int dis = sqrt(pow(x-p->object->x1,2)+pow(y-p->object->y1,2));
				if(p->object->r>=dis){
					return p;
				}
			}
			p=p->next;
		}
	}
	return NULL;
}

void Delete(NODE **pp) {
	// your implementation
	deleteNode(&objlist,pp);
}

void moveFront(NODE **p) {
	// your implementation
	insert_back(&objlist,p);
}

void moveBack(NODE **p) {
	// your implementation
	insert_front(&objlist,p);
}

