/*
 * Description: implementation of object.hpp
 * Author: HBF
 * Version: 2021-08-24
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "object.hpp"

void insert(LIST *list, SHAPE *object) {
// ...
	NODE *n = (NODE*)malloc(sizeof(NODE));
	n->object=object;
	if (list->start == NULL){
		n->prev = NULL;
		n->next = NULL;
		list->start = n;
		list->end = n;
	}else{
		list->end->next = n;
		n->prev=list->end;
		n->next=NULL;
		list->end = n;
	}





}
void insert_front(LIST *list,NODE **node){//move back
	if((*node)->prev!=NULL){
		if((*node)->next!=NULL){
			(*node)->prev->next=(*node)->next;
			(*node)->next->prev=(*node)->prev;
			(*node)->prev = NULL;
			(*node)->next = list->start;
			list->start->prev=(*node);
			list->start=(*node);
		}else{
			(*node)->prev->prev=(*node);
			(*node)->prev->next=NULL;
			(*node)->prev=NULL;
			(*node)->next=list->start;
			list->start=(*node);
			list->end=(*node)->next;
		}

	}

}
void insert_back(LIST *list,NODE **node){//move front
	if((*node)->next!=NULL){
		if((*node)->prev!=NULL){
			(*node)->prev->next=(*node)->next;
			(*node)->next->prev=(*node)->prev;
			(*node)->prev = list->end;
			(*node)->next = NULL;
			list->end->next=(*node);
			list->end=(*node);
		}else{
			(*node)->next->next=(*node);
			(*node)->next->prev=NULL;
			list->start=(*node)->next;
			list->end = (*node);
			(*node)->prev=(*node)->next;
			(*node)->next=NULL;
		}


	}

}
void deleteNode(LIST *list, NODE **selectp) {
// ...
	if ((*selectp)->prev== NULL){//deleting front
		if(list->start->next!=NULL){
			list->start=(*selectp)->next;//updating the list start
			(*selectp)->next->prev=NULL;//leting the new front previous become NULL
			free((*selectp)->object);//free object of pointer
			free(*selectp);//let it go~

		}else{
			list->start = NULL;
			list->end = NULL;
			free((*selectp)->object);
			free(*selectp);


		}

	}else if ((*selectp)->next==NULL){//deleting end
		if (list->end->prev!=NULL){
			list->end=(*selectp)->prev;//updating the list end
			(*selectp)->prev->next=NULL;//leting the new end next pointing to NULL
			free((*selectp)->object);
			free(*selectp);//let it go
		}else{
			list->start=NULL;
			list->end = NULL;
			free((*selectp)->object);
			free(*selectp);
		}

	}else{//deleting in the middle
		(*selectp)->prev->next=(*selectp)->next;
		(*selectp)->next->prev=(*selectp)->prev;
		free((*selectp)->object);
		free(*selectp);

	}
	*selectp=NULL;
}

void clearList(LIST *list) {
// ...
	NODE *temp = NULL;
	NODE *p =list->start;

	while(p){
		temp = p->next;
		list->start=list->start->next;
		free(p->object);
		free(p);
		p=temp;
	}
	list->start=NULL;
	list->end=NULL;
}
void drawOutline(SHAPE*object){
	if(object->type==RECTANGLE){
		glColor3f(object->sr,object->sg,object->sb);
		glLineWidth(object->swidth);
		glBegin(GL_LINES);
		glVertex2i(object->x1,object->y1);
		glVertex2i(object->x1,object->y2);
		glVertex2i(object->x2,object->y2);
		glVertex2i(object->x2,object->y1);
		glVertex2i(object->x1,object->y1);
		glVertex2i(object->x2,object->y1);
		glVertex2i(object->x1,object->y2);
		glVertex2i(object->x2,object->y2);
		glEnd();

	}else if (object->type==CIRCLE){
		glLineWidth(object->swidth);
		glColor3f(object->sr,object->sg,object->sb);
		circleMidpoint(object->x1,object->y1,object->x2,object->y2);
	}
}
void drawShape(SHAPE *object) {
	if (object->type == RECTANGLE) {  // rectangle
		// draw filled rectangle

		int x1 = object->x1;
		int x2 = object->x2;
		int y1 = object->y1;
		int y2 = object->y2;
		glBegin(GL_POLYGON);
			glColor3f(object->fr,object->fg,object->fb);//set color to shape rgb value
			glVertex2i(x1, y1);
			glVertex2i(x2, y1);
			glVertex2i(x2, y2);
			glVertex2i(x1, y2);
		glEnd();
		// draw outline
		 drawOutline(object);
	} else if (object->type == CIRCLE) {  // circle
		// draw filled circle

		int x1 = object->x1;
		int x2 = object->x2;
		int y1 = object->y1;
		int y2 = object->y2;


		glColor3f(object->fr,object->fg,object->fb);//set color to shape rgb value
		int r = sqrt(pow(x2-x1,2)+pow(y2-y1,2));
		object->r = r;
		circleMidpointFill(x1,y1,x2,y2);
		// draw outline
		drawOutline(object);

	}
}



void drawShapeHighLight(SHAPE *object) {
	// draw outline with high light color
	if(object->type==RECTANGLE){
		glColor3f(1.0,1.0,0.0);
		glLineWidth(object->swidth);
		glBegin(GL_LINES);
		glVertex2i(object->x1,object->y1);
		glVertex2i(object->x1,object->y2);
		glVertex2i(object->x2,object->y2);
		glVertex2i(object->x2,object->y1);
		glVertex2i(object->x1,object->y1);
		glVertex2i(object->x2,object->y1);
		glVertex2i(object->x1,object->y2);
		glVertex2i(object->x2,object->y2);
		glEnd();

	}else if (object->type==CIRCLE){
		glLineWidth(object->swidth);
		glColor3f(1.0,1.0,0.0);
		circleMidpoint(object->x1,object->y1,object->x2,object->y2);
	}
}

void drawList(LIST *list) {
	NODE *p = list->start;
	while (p) {
		drawShape(p->object);
		p = p->next;
	}
}

void setPixel(GLint x, GLint y) {
	glPointSize(2.0);
	glBegin(GL_POINTS);
	glVertex2i(x, y);
	glEnd();
}

// draw points on line of circle
void circlePlotPoints(const GLint& xc, const GLint& yc, const GLint& x,
		const GLint& y) {
// ...
	setPixel(xc+x,yc+y);
	setPixel(xc+x,yc-y);
	setPixel(xc+y,yc+x);
	setPixel(xc+y,yc-x);
	setPixel(xc-x,yc+y);
	setPixel(xc-x,yc-y);
	setPixel(xc-y,yc+x);
	setPixel(xc-y,yc-x);
}

// draw circle main function
void circleMidpoint(GLint x1, GLint y1, GLint x2, GLint y2) {
	// ...
	GLint r = sqrt(pow(x2-x1,2)+pow(y2-y1,2));

	GLint p = 1 - r; // Initial value of midpoint parameter.
	GLint x = 0, y = r; // Set coordinates for top point of circle.
	/* Plot the initial point in each circle quadrant. */
	circlePlotPoints(x1, y1, x, y);
	while (x < y) {
		x++;
		if (p < 0){
			p += 2 * x + 1;
		}
		else {
			y--;
			p += 2 * (x - y) + 1;
		}
		circlePlotPoints(x1, y1, x, y);
	}
}

void circlePlotPointsFill(GLint x1, GLint y1, GLint x, GLint y) {
	// ...
	glLineWidth(2.0);
	glBegin(GL_LINES);
	glVertex2i(x1-x,y1-y);
	glVertex2i(x1-x,y1+y);
	glVertex2i(x1+x,y1-y);
	glVertex2i(x1+x,y1+y);
	glVertex2i(x1-y,y1-x);
	glVertex2i(x1-y,y1+x);
	glVertex2i(x1+y,y1-x);
	glVertex2i(x1+y,y1+x);
	glEnd();

}

void circleMidpointFill(GLint x1, GLint y1, GLint x2, GLint y2) {
	// ...
	GLint r = sqrt(pow(x2-x1,2)+pow(y2-y1,2));
	GLint p = 1 - r; // Initial value of midpoint parameter.
	GLint x = 0, y = r; // Set coordinates for top point of circle.
	/* Plot the initial point in each circle quadrant. */
	circlePlotPointsFill(x1, y1, x, y);
	while (x < y) {
		x++;
		if (p < 0) {
			p += 2 * x + 1;
		}
		else {
		y--;
		p += 2 * (x - y) + 1;
		}
		circlePlotPointsFill(x1, y1, x, y);
}
}
