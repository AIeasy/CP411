Name: Zhongxin Hu (type your name here)
ID: 180896440
Email: huxx6440@mylaurier.ca
WorkID: cp411-a2
Statement: I claim that the enclosed submission is my individual work.

Fill in the self-evaluation in the following evaluation grid.
Symbols: Q -- Question, T -- Lab tasks
Field format: [self-evaluation/total marks/marker's evaluation]

For example, you put your self-evaluation, say 2, like [2/2/*]. 
If marker gives different evaluation value say 1, it will show 
[2/2/1] in the marking report. 

Evaluation grid: [self-evaluation/total/marker-evaluation]

A2

Q1 Graphics pipeline

Q1.1 Primitives                           [4/4/*]
Q1.2 Coordinate systems & transformations [3/3/*]
Q1.3 Scan conversion                      [3/3/*]

Q2 OpenGL and Glut

Q2.1 OpenGL primitives                    [4/4/*]
Q2.2 Interactive graphics                 [3/3/*]
Q2.3 Bitmap file I/O                      [3/3/*]

Q3 SimpleDraw

Q3.1 Display window and menu              [10/10/*]
Q3.2 Data structures                      [10/10/*]
Q3.3 Draw rectangles                      [5/5/*]
Q3.4 Draw circles                         [10/10/*]
Q3.5 Edit features                        [20/20/*]
Q3.6 Save/Open SVG files                  [10/10/*]
Q3.7 Export to bitmap                     [5/5/*]
Q3.8 Circle&Square artwork                [10/10/*]

Total:                                    [100/100/*]