/*
 *  SimpleView : reference design
 *  Author: HBF
 *  Version: 2021-10-15 (update)
 */
#include "Cube.hpp"
#include "Camera.hpp"
#include <stdio.h>
#include <iostream>
extern Camera myCamera;
extern Light myLight;
extern RenderMode renderMode;
extern CullMode cullMode;

Cube::Cube() {
    vertex[0][0] = -1; vertex[0][1] = -1; vertex[0][2] = -1;
    vertex[1][0] = -1; vertex[1][1] = 1;  vertex[1][2] = -1;
    vertex[2][0] = 1;  vertex[2][1] = 1;  vertex[2][2] = -1;
    vertex[3][0] = 1;  vertex[3][1] = -1; vertex[3][2] = -1;
    vertex[4][0] = -1; vertex[4][1] = -1; vertex[4][2] = 1;
    vertex[5][0] = -1; vertex[5][1] = 1;  vertex[5][2] = 1;
    vertex[6][0] = 1;  vertex[6][1] = 1;  vertex[6][2] = 1;
    vertex[7][0] = 1;  vertex[7][1] = -1; vertex[7][2] = 1;

    face[0][0] = 0; face[0][1] = 1; face[0][2] = 2; face[0][3] = 3;
    face[1][0] = 7; face[1][1] = 6; face[1][2] = 5; face[1][3] = 4;
    face[2][0] = 0; face[2][1] = 4; face[2][2] = 5; face[2][3] = 1;
    face[3][0] = 2; face[3][1] = 1; face[3][2] = 5; face[3][3] = 6;
    face[4][0] = 3; face[4][1] = 2; face[4][2] = 6; face[4][3] = 7;
    face[5][0] = 0; face[5][1] = 3; face[5][2] = 7; face[5][3] = 4;

	// faceColor
	faceColor[0][0] = 1.0, faceColor[0][1] = 0.0; faceColor[0][2] = 0.0;
    faceColor[1][0] = 0.0, faceColor[1][1] = 1.0; faceColor[1][2] = 0.0;
    faceColor[2][0] = 0.0, faceColor[2][1] = 0.0; faceColor[2][2] = 1.0;
    faceColor[3][0] = 1.0, faceColor[3][1] = 1.0; faceColor[3][2] = 0.0;
    faceColor[4][0] = 1.0, faceColor[4][1] = 0.0; faceColor[4][2] = 1.0;
    faceColor[5][0] = 0.0, faceColor[5][1] = 1.0; faceColor[5][2] = 1.0;

	// more

	// set or compute face normals

	for(int i=0;i<6;i++){
		Vector V1,V2,N;
		V1.x = vertex[face[i][1]][0] - vertex[face[i][0]][0];
		V1.y = vertex[face[i][1]][1] - vertex[face[i][0]][1];
		V1.z = vertex[face[i][1]][2] - vertex[face[i][0]][2];
		V2.x = vertex[face[i][2]][0] - vertex[face[i][1]][0];
		V2.y = vertex[face[i][2]][1] - vertex[face[i][1]][1];
		V2.z = vertex[face[i][2]][2] - vertex[face[i][1]][2];
		N = V1.cross(V2);
		N.normalize();
		faceNormal[i][0]=N.x;
		faceNormal[i][1]=N.y;
		faceNormal[i][2]=N.z;
	}
	// more

    vertexColor[6][0] = 0.5;
    vertexColor[6][1] = 0.5;
    vertexColor[6][2] = 0.5;
	for (int j =0;j<6;j++){
		for(int k=0;k<3;k++){
			vertexColor[j][k]=faceColor[j][k];
		}
	}
    for (int l=0;l<8;l++){
        for (int m=0;m<3;m++){
            vertexNormal[l][m] = vertex[l][m];
        }
    }
	r = 1.0;
	g = 0.0;
	b = 0.0;
}

void Cube::drawFace(int i) {
	GLfloat shade = 1;
	if (renderMode==WIRE){
        glColor3f(r,g,b);
        glBegin(GL_LINE_LOOP);
        for (int j = 0; j < 4; j++) {
            glVertex3fv(vertex[face[i][j]]);
        }
        glEnd();
	}else{
		if (renderMode == CONSTANT) {
			if(myLight.on){
				shade = getFaceShade(i,myLight);

			}
			glColor3f(faceColor[i][0]*shade,faceColor[i][1]*shade,faceColor[i][2]*shade);
			glBegin(GL_POLYGON);
			for (int k = 0; k < 4; k++) {
				glVertex3fv(vertex[face[i][k]]);
			}
			glEnd();
		}else if (renderMode == FLAT){
            glShadeModel(GL_FLAT);
            if(myLight.on){
                shade = getVertexShade(i, myLight);
            }
            glColor3f(vertexColor[face[i][0]][0]*shade,vertexColor[face[i][0]][2]*shade,vertexColor[face[i][0]][1]*shade);
            glBegin(GL_POLYGON);
            glVertex3fv(vertex[face[i][0]]);
            glVertex3fv(vertex[face[i][1]]);
            glVertex3fv(vertex[face[i][2]]);
            glVertex3fv(vertex[face[i][3]]);
            glEnd();
        } else if (renderMode == SMOOTH){
            glEnable(GL_NORMALIZE);
            glShadeModel(GL_SMOOTH);
            glBegin(GL_POLYGON);
            for (int j=0;j<4;j++){
                if(myLight.on){
                    shade = getVertexShade(face[i][j], myLight);
                }
                glColor3f(vertexColor[face[i][j]][0]*shade,vertexColor[face[i][j]][2]*shade,vertexColor[face[i][j]][1]*shade);
                glNormal3f(vertexNormal[face[i][j]][0],vertexNormal[face[i][j]][1],vertexNormal[face[i][j]][2]);
                glVertex3fv(vertex[face[i][j]]);
            }
            glEnd();
        }
	}
}

void Cube::draw() {
	glPushMatrix();
	this->ctmMultiply();
	glScalef(s, s, s);

	for (int i = 0; i < 6; i++) {
		if(cullMode == BACKFACE && !isFrontface(i, myCamera)){
			continue;
		}
		drawFace(i);
	}
	glPopMatrix();
}

bool Cube::isFrontface(int faceindex, Camera camera) {
// your implementation
	GLfloat vec[4],value;
	vec[0]=faceNormal[faceindex][0];
	vec[1]=faceNormal[faceindex][1];
	vec[2]=faceNormal[faceindex][2];
	vec[3]=0;
	if(!pmc){
		mc.multiplyVector(vec);
		value = (mc.mat[0][3] - camera.eye.x)*vec[0]+
                (mc.mat[1][3] - camera.eye.y)*vec[1]+
                (mc.mat[2][3] - camera.eye.z)*vec[2];
	}else{
		pmc->multiplyVector(vec);
        value = (pmc->mat[0][3] - camera.eye.x)*vec[0]+
                (pmc->mat[1][3] - camera.eye.y)*vec[1]+
                (pmc->mat[2][3] - camera.eye.z)*vec[2];
    }

	return value<0;


}

GLfloat Cube::getFaceShade(int faceindex, Light light) {
	GLfloat shade = 1, v[4], s[4], temp;

	// your implementation
    v[0]= vertex[face[faceindex][0]][0];
    v[1]= vertex[face[faceindex][0]][1];
    v[2]= vertex[face[faceindex][0]][2];
    v[3]=1;
    ((!this->pmc)?mc.multiplyVector(v):pmc->multiplyVector(v));
    Matrix matrix = light.getMC();
    s[0]=matrix.mat[0][3]-v[0];
    s[1]=matrix.mat[1][3]-v[1];
    s[2]=matrix.mat[2][3]-v[2];
    temp = sqrt(s[0]*s[0] + s[1]*s[1] + s[2]*s[2]);
    s[0] /= temp;
    s[1] /= temp;
    s[2] /= temp;
    v[0] = faceNormal[faceindex][0];
    v[1] = faceNormal[faceindex][1];
    v[2] = faceNormal[faceindex][2];
    v[3] = 0;
    ((!this->pmc)?mc.multiplyVector(v):pmc->multiplyVector(v));
    temp = sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
    v[0] /= temp;
    v[1] /= temp;
    v[2] /= temp;
    temp = v[0]*s[0] + v[1]*s[1] + v[2]*s[2];
    shade = light.I * light.Rd * temp;
	return shade;
}
GLfloat Cube::getVertexShade(int faceindex, Light light) {
	GLfloat shade = 1, v[4], s[4], temp;

	// your implementation
    v[0]= vertex[face[faceindex][0]][0];
    v[1]= vertex[face[faceindex][0]][1];
    v[2]= vertex[face[faceindex][0]][2];
    v[3]=1;
    ((!this->pmc)?mc.multiplyVector(v):pmc->multiplyVector(v));
    Matrix matrix = light.getMC();
    s[0]=matrix.mat[0][3]-v[0];
    s[1]=matrix.mat[1][3]-v[1];
    s[2]=matrix.mat[2][3]-v[2];
    temp = sqrt(s[0]*s[0] + s[1]*s[1] + s[2]*s[2]);
    s[0] /= temp;
    s[1] /= temp;
    s[2] /= temp;
    v[0] = vertexNormal[faceindex][0];
    v[1] = vertexNormal[faceindex][1];
    v[2] = vertexNormal[faceindex][2];
    v[3] = 0;
    ((!this->pmc)?mc.multiplyVector(v):pmc->multiplyVector(v));
    temp = sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
    v[0] /= temp;
    v[1] /= temp;
    v[2] /= temp;
    temp = v[0]*s[0] + v[1]*s[1] + v[2]*s[2];
    shade = light.I * light.Rd * temp;
	return shade;
}


